import React, { useState, useEffect } from "react";
import { Table } from "antd";

const AppointmentList = () => {
  const [appointmentData, setAppointmentData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const todayDate = new Date().toISOString().slice(0, 10);
  const oneMonthFromNow = new Date(
    new Date().setMonth(new Date().getMonth() + 1)
  )
    .toISOString()
    .slice(0, 10);
  const visitType = 41;
  const provider_id = 45;
  const fetchAppointments = async () => {
    try {
      const headers = new Headers();
      //   headers.set(
      //     "Authorization",
      //     "Basic " + btoa("dot_pk_Jwyr35rA1E:dot_sk_eQfLfWvveT")
      //   );
      const include_work_schedule = "true";
      const url = `https://dt.md-hq.com/api/v1/appointments?provider_id=${provider_id}&limit=1000&start_date=${todayDate}&end_date=${oneMonthFromNow}&include_work_schedule=${include_work_schedule}`;
      const response = await fetch(url, {
        headers: headers,
      });
      const data = await response.json();

      const appointmentData = data.data.reduce((accumulator, currentValue) => {
        if (currentValue.available_appointment_types.includes(visitType)) {
          accumulator.push({
            appointmentTypes:
              currentValue.available_appointment_types.join(", "),
            start: currentValue.start_date_time,
            end: currentValue.end_date_time,
          });
        }
        return accumulator;
      }, []);

      setAppointmentData(appointmentData);
      setLoading(false);
    } catch (error) {
      setError(error);
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAppointments();
  }, []);

  const columns = [
    {
      title: "Appointment Types",
      dataIndex: "appointmentTypes",
      key: "appointmentTypes",
    },
    {
      title: "Start",
      dataIndex: "start",
      key: "start",
    },
    {
      title: "End",
      dataIndex: "end",
      key: "end",
    },
  ];

  if (error) {
    return <div>Error: {error.message}</div>;
  } else {
    return (
      <Table
        dataSource={appointmentData}
        columns={columns}
        loading={loading}
        pagination={false}
        rowKey={(record, index) => index}
      />
    );
  }
};

export default AppointmentList;
