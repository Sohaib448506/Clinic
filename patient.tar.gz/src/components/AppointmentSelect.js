import { useState, useEffect } from "react";
import { Radio, Button, Form } from "antd";
import { useHistory } from "react-router-dom";

const { Group: RadioGroup } = Radio;

const healthProviderList = [
  { label: "Shantel", value: "39" },
  { label: "David", value: "45" },
  { label: "Jen", value: "34" },
  { label: "Brannick", value: "8" },
  { label: "Karen", value: "56" },
  { label: "Grame", value: "71" },
  { label: "Maren", value: "68" },
  { label: "Levi", value: "25" },
];

const appointmentTypeList = [
  { label: "In-person Acute Care 15 Minutes", value: "41" },
  { label: "Telehealth Acute Care - 15 Min", value: "13" },
  { label: "Acute Care (New Patient) - 15 Min", value: "46" },
];

const AppointmentForm = ({ onNext }) => {
  const [appointmentType, setAppointmentType] = useState("");
  const [healthProvider, setHealthProvider] = useState("");

  const handleAppointmentTypeChange = (e) => {
    setAppointmentType(e.target.value);
  };

  const handleHealthProviderChange = (e) => {
    setHealthProvider(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // Add your form submission logic here
    onNext({ appointmentType, healthProvider });
  };

  return (
    <div className="centerWhiteBox">
      <div className="text-center">
        <h1>Schedule An Appointment</h1>
      </div>
      <div className="instructionsText">
        <p>
          <strong>Choose Appointment Type</strong>
        </p>
      </div>
      <form
        style={{ textAlign: "left" }}
        className="emailForm"
        onSubmit={handleSubmit}
      >
        <div style={{ paddingLeft: "20px" }}>
          <RadioGroup
            onChange={handleAppointmentTypeChange}
            value={appointmentType}
          >
            {appointmentTypeList.map((type) => (
              <Radio key={type.value} value={type.value}>
                {type.label}
              </Radio>
            ))}
          </RadioGroup>
        </div>
        <br />
        <div className="instructionsText">
          <p>
            <strong>Choose A Provider</strong>
          </p>
        </div>

        <div style={{ paddingLeft: "20px" }}>
          <RadioGroup
            onChange={handleHealthProviderChange}
            value={healthProvider}
          >
            {healthProviderList.map((provider) => (
              <Radio key={provider.value} value={provider.value}>
                {provider.label}
              </Radio>
            ))}
          </RadioGroup>
        </div>
        {/* <Button type="primary" htmlType="submit">
          Continue
        </Button> */}
      </form>
      <NewPatientForm />
    </div>
  );
};

const StepTwo = () => {
  const providerList = { "Brannick Riggs": 8, "Mike Reier": 7 };
  const [availableTimes, setAvailableTimes] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const startDateTime = "";
      const endDateTime = "";
      const providerIds = "[8,14]";
      const ptId = "2";
      const title = "Initial Visit";
      const appointmentNote = "John has been having headaches";
      const appointmentType = "Office Visit";

      const apiUrl =
        "https://pk_thriver_Bh70agyEF4LH:sk_thriver_ZooxItIYiN2e3RUxwi@thriverstaff.md-hq.com/api/v1/appointments";

      const response = await fetch(apiUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          start_date_time: startDateTime,
          end_date_time: endDateTime,
          provider_ids: providerIds,
          pt_id: ptId,
          title,
          appointment_note: appointmentNote,
          appointment_type: appointmentType,
        }),
      });
      const data = await response.json();

      const alreadyScheduled = data.data
        .map((appointment) => {
          const date = new Date(appointment.start_date_time);
          const hours = date.getHours();
          const minutes = date.getMinutes();
          return `${hours}:${minutes < 10 ? "0" + minutes : minutes} ${
            hours >= 12 ? "pm" : "am"
          }`;
        })
        .filter((time) => time.startsWith("9") || time.startsWith("1"));

      const timeSlots = [
        "9:00 am",
        "10:00 am",
        "11:00 am",
        "12:00 pm",
        "1:00 pm",
        "2:00 pm",
        "3:00 pm",
        "4:00 pm",
        "5:00 pm",
        "6:00 pm",
      ];

      const availableTimes = timeSlots.filter(
        (time) => !alreadyScheduled.includes(time)
      );

      setAvailableTimes(availableTimes);
    };

    fetchData();
  }, []);

  const handleSubmit = (event) => {
    event.preventDefault();
    // handle form submission
  };

  return (
    <div className="centerWhiteBox">
      <div className="titleContent">
        <h1>New Patient Form</h1>
      </div>
      <div className="instructionsText">
        <p>Please Select Your Appointment Time</p>
      </div>
      <form
        style={{ padding: "20px" }}
        className="emailForm"
        method="POST"
        action="scheduleAppointment.php"
        target="_self"
        onSubmit={handleSubmit}
      >
        <Radio.Group>
          {availableTimes.map((time) => (
            <Radio key={time} className="radioButton" value={time}>
              {time}
            </Radio>
          ))}
        </Radio.Group>
        <br />
        <Button type="primary" htmlType="submit">
          Submit
        </Button>
      </form>
    </div>
  );
};

const NewPatientForm = ({ handleSubmit }) => {
  const history = useHistory();
  const { Item } = Form;

  const providerList = {
    "Brannick Riggs": 8,
    "Mike Reier": 7,
  };

  const alreadyScheduled = ["9:00 am", "1:00 pm", "4:00 pm"]; // example array

  const timeOptions = [
    "9:00 am",
    "10:00 am",
    "11:00 am",
    "12:00 pm",
    "1:00 pm",
    "2:00 pm",
    "3:00 pm",
    "4:00 pm",
    "5:00 pm",
    "6:00 pm",
  ];
  const [form] = Form.useForm();
  const [availableTimes, setAvailableTimes] = useState([]);

  // const handleProviderChange = (value) => {
  //   // Fetch available appointment times for selected provider
  //   // and update availableTimes state
  //   const providerId = providerList[value];
  //   // Example logic for filtering out already scheduled times
  //   const available = timeOptions.filter(
  //     (time) => !alreadyScheduled.includes(time)
  //   );
  //   setAvailableTimes(available);
  // };
  useEffect(() => {
    setAvailableTimes(
      timeOptions.filter((time) => !alreadyScheduled.includes(time))
    );
  }, []);

  return (
    <div className="centerWhiteBox">
      {/* <div className="titleContent">
        <h1>New Patient Form</h1>
      </div> */}
      <br />
      <div className="instructionsText">
        <p>
          <strong>Please Select Your Appointment Time</strong>
        </p>
      </div>
      <Form
        className="emailForm"
        onFinish={() => {
          alert("Form has been submitted sucessfully");
          history.push("/sign-in");
        }}
        form={form}
      >
        {/* <Item
          label="Healthcare Provider"
          name="provider"
          rules={[{ required: true, message: "Please select a provider" }]}
        >
          <Radio.Group onChange={(e) => handleProviderChange(e.target.value)}>
            {Object.keys(providerList).map((name) => (
              <Radio key={name} value={name}>
                {name}
              </Radio>
            ))}
          </Radio.Group>
        </Item> */}
        <Item
          label="Appointment Time"
          name="appointmentTime"
          rules={[
            { required: true, message: "Please select an appointment time" },
          ]}
        >
          <Radio.Group>
            {availableTimes.map((time) => (
              <Radio key={time} value={time}>
                {time}
              </Radio>
            ))}
          </Radio.Group>
        </Item>
        <Item>
          <div className="text-end">
            <Button type="primary" htmlType="submit">
              Submit
            </Button>
          </div>
        </Item>
      </Form>
    </div>
  );
};

const TwoStepForm = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({});

  const handleNext = (data) => {
    setFormData(data);
    setStep(2);
  };

  const handleSubmit = (data) => {
    // do something with form data, like sending it to a server
    console.log(data, 44444);
    alert("Form has been submitted sucessfully");
    // history.push("/sign-in");
    setStep(1);
    setFormData({});
  };

  return (
    <div className="p-4" style={{ maxWidth: "900px", margin: "auto" }}>
      <AppointmentForm onNext={handleNext} />
      {/* {step === 1 && <AppointmentForm onNext={handleNext} />}
      {step === 2 && <NewPatientForm onSubmit={handleSubmit} data={formData} />} */}
    </div>
  );
};

export default TwoStepForm;
